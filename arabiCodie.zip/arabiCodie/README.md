
## Features

- Streaming, fast responses from ChatGPT
- Send generated code directly to text or terminal buffers
- Comes with useful prompt presets:
  - Explain code
  - Diagnose error message
- Feed your current selection or active tab into the prompt

## License

MIT
