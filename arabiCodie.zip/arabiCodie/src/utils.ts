import fetch from 'node-fetch';
import {username} from 'username';
import { remark } from "remark";
import stripMarkdown from "strip-markdown";
import { marked } from 'marked';
export function undefinedIfEmpty(str: string | undefined) {
  return (str ?? "").length > 0 ? str : undefined;
}

export function createPrompt(
  userInput?: string,
  preset?: string,
  currentSelection?: string,
  currentBuffer?: string
): string {
  if (preset) {
    return preset + "\n" + (userInput ?? currentSelection ?? currentBuffer ?? "");
  }
  // If preset is not set, return selection + userInput or just user input if no selection
  else {
    // (textarea can be empty - like for an error message)
    if (currentSelection) {
      return `${currentSelection}

    ${userInput}`;
    } else {
      // We don't allow current buffer because otherwise, there would be no way to do just
      // do prompts directly like "Generate a discord bot that tells funny jokes"
      // TODO: Check out OG demo to see what they do
      return userInput ?? "";
    }
  }
  return "";
}

export async function markdownToText1(markdown?: string) {
  return remark().use(stripMarkdown).processSync(markdown ?? "").toString();
}
export async function markdownToTextNew(markdown?: string) {
  // Parse the markdown and remove HTML tags
  return marked(markdown || "");
}
export async function sendMessage(message?:string) {
  try{
    const body = {
      "messages":[{
        "role":"system",
        "content": message
      }
    ]
    }
    let userId = await username();

    let response = await fetch('https://tapi.arabbank.com/v1/openai/openai/deployments/gpt-4o-mini/chat/completions?api-version=2024-06-01',
      {
          method: 'POST',
          headers: {
              "Content-Type": "application/json",
              "user-id": userId || "Acabes",
              "api-key":'c8f572982a3047d6bb537891e117548c',
              "client_id":'EVi8mEgHp1gwPdAYVAgBy9EBdz0Cimt0'
          },
          body: JSON.stringify(body)
      }
  );
  
  let responseType = response.headers.get('content-type');
            let data = null;
            if (responseType && responseType.indexOf('application/json') > -1) {
                let t = await response.text();
                try {
                    data = JSON.parse(t);
                }
                catch {
                    data = t;
                }
            }
            else {
                data = await response.text();
            }
            if (response.ok) {
                if (data) 
                  return data;
                else
                  return response;
            }
        } 
           catch (error) {
            throw error
        }
            
  }
